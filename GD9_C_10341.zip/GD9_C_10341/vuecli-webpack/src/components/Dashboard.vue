<template>
  <v-main>
    <h1 class="text-h3 font-weight-medium mb-5 text-left">Dashboard</h1>
    <p class="subtitle-1 text-left">Ini Dashboard</p>
  </v-main>
</template>
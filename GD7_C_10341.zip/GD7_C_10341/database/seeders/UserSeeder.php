<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use DB;
use Carbon\Carbon;

class UserSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //GD11
        DB::table('users')->insert([
            'name' => 'alesandro',
            'email' => '10341@students.uajy.ac.id',
            'password' => '$2b$10$BIPqrcsIaJKmVtS6aawt8eIeGCJdoqCPk7hcoTasj3VoCtwew1vXC',
            'created_at' => Carbon::now(),
            'updated_at' => Carbon::now()
        ]);
    }
}
